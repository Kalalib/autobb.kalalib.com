(() => {
    if (window.top !== window.self) {
        return;
    }

    if (window.location.origin !== "https://blackboard.cuhk.edu.hk") {
        return;
    }

    if (window.__bbDownloaderRunning) {
        return;
    }
    window.__bbDownloaderRunning = true;

    String.prototype.rsplit = function(sep, maxsplit) {
        var split = this.split(sep);
        return maxsplit ? [ split.slice(0, -maxsplit).join(sep) ].concat(split.slice(-maxsplit)) : split;
    }

    const DEFAULT_WORKER_BASE_URL = "https://autobbapi.kalalib.com";
    const PROFILE_URL = "https://blackboard.cuhk.edu.hk/ultra/profile";
    const ENABLE_FOLDER_TRAVERSAL = true;
    let verifiedStripeCustomerId = "";
    let cachedBlackboardXsrfToken = "";
    let runRootFolder = "";
    const visitedPageUrls = new Set();
    const visitedFileUrls = new Set();
    const zipFolders = new Set();
    let progressUi = null;
    let downloadAllButton = null;
    let workflowInProgress = false;
    let activeCourseLabel = "";
    let courseContentHeadingAnchor = null;
    let lastCourseScreenUrl = "";
    let progressStartedAtMs = 0;
    let progressTimerId = null;

    function formatElapsedDuration(ms) {
        const totalSeconds = Math.max(0, Math.floor((Number(ms) || 0) / 1000));
        const minutes = Math.floor(totalSeconds / 60);
        const seconds = totalSeconds % 60;
        return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
    }

    function updateElapsedLabel() {
        if (!progressUi || !progressUi.elapsed) {
            return;
        }

        if (!progressStartedAtMs) {
            progressUi.elapsed.textContent = "Elapsed: 00:00";
            return;
        }

        const elapsedMs = Date.now() - progressStartedAtMs;
        progressUi.elapsed.textContent = `Elapsed: ${formatElapsedDuration(elapsedMs)}`;
    }

    function stopProgressElapsedTimer() {
        if (progressTimerId !== null) {
            window.clearInterval(progressTimerId);
            progressTimerId = null;
        }
    }

    function startProgressElapsedTimer() {
        progressStartedAtMs = Date.now();
        updateElapsedLabel();
        stopProgressElapsedTimer();
        progressTimerId = window.setInterval(updateElapsedLabel, 1000);
    }

    function setProgressCloseButtonVisible(visible) {
        const ui = ensureProgressWidget();
        ui.closeButton.style.display = visible ? "inline-flex" : "none";
    }

    function ensureProgressWidget() {
        if (progressUi) {
            return progressUi;
        }

        const container = document.createElement("div");
        container.style.position = "fixed";
        container.style.right = "16px";
        container.style.bottom = "16px";
        container.style.width = "320px";
        container.style.maxWidth = "calc(100vw - 32px)";
        container.style.background = "rgba(17, 24, 39, 0.95)";
        container.style.color = "#e5e7eb";
        container.style.border = "1px solid rgba(255, 255, 255, 0.14)";
        container.style.borderRadius = "12px";
        container.style.boxShadow = "0 12px 30px rgba(0, 0, 0, 0.35)";
        container.style.padding = "12px";
        container.style.zIndex = "2147483647";
        container.style.fontFamily = "Segoe UI, Tahoma, sans-serif";
        container.style.fontSize = "12px";

        const header = document.createElement("div");
        header.style.display = "flex";
        header.style.alignItems = "center";
        header.style.justifyContent = "space-between";
        header.style.marginBottom = "6px";

        const title = document.createElement("div");
        title.textContent = "Blackboard Downloader";
        title.style.fontWeight = "600";

        const rightControls = document.createElement("div");
        rightControls.style.display = "inline-flex";
        rightControls.style.alignItems = "center";
        rightControls.style.gap = "8px";

        const elapsed = document.createElement("div");
        elapsed.textContent = "Elapsed: 00:00";
        elapsed.style.color = "#94a3b8";
        elapsed.style.fontSize = "11px";

        const closeButton = document.createElement("button");
        closeButton.type = "button";
        closeButton.setAttribute("aria-label", "Close progress panel");
        closeButton.innerHTML = '<svg viewBox="0 0 512 512" width="12" height="12" aria-hidden="true" focusable="false"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="48" d="M368 368L144 144M368 144L144 368"></path></svg>';
        closeButton.style.display = "none";
        closeButton.style.width = "20px";
        closeButton.style.height = "20px";
        closeButton.style.border = "1px solid rgba(255,255,255,0.28)";
        closeButton.style.borderRadius = "999px";
        closeButton.style.background = "transparent";
        closeButton.style.color = "#e5e7eb";
        closeButton.style.cursor = "pointer";
        closeButton.style.display = "none";
        closeButton.style.alignItems = "center";
        closeButton.style.justifyContent = "center";
        closeButton.style.padding = "0";
        closeButton.addEventListener("click", () => {
            stopProgressElapsedTimer();
            progressStartedAtMs = 0;
            if (container.parentElement) {
                container.parentElement.removeChild(container);
            }
            progressUi = null;
        });

        header.appendChild(title);
        rightControls.appendChild(elapsed);
        rightControls.appendChild(closeButton);
        header.appendChild(rightControls);

        const status = document.createElement("div");
        status.textContent = "Starting...";
        status.style.color = "#cbd5e1";
        status.style.marginBottom = "8px";
        status.style.whiteSpace = "nowrap";
        status.style.overflow = "hidden";
        status.style.textOverflow = "ellipsis";

        const track = document.createElement("div");
        track.style.width = "100%";
        track.style.height = "10px";
        track.style.background = "rgba(255, 255, 255, 0.15)";
        track.style.borderRadius = "999px";
        track.style.overflow = "hidden";

        const bar = document.createElement("div");
        bar.style.width = "0%";
        bar.style.height = "100%";
        bar.style.background = "linear-gradient(90deg, #22d3ee, #34d399)";
        bar.style.transition = "width 180ms ease";
        track.appendChild(bar);

        const detail = document.createElement("div");
        detail.textContent = "0%";
        detail.style.marginBottom = "6px";
        detail.style.color = "#94a3b8";
        detail.style.whiteSpace = "nowrap";
        detail.style.overflow = "hidden";
        detail.style.textOverflow = "ellipsis";

        container.appendChild(header);
        container.appendChild(status);
        container.appendChild(detail);
        container.appendChild(track);
        document.body.appendChild(container);

        progressUi = { container, status, bar, detail, elapsed, closeButton, percent: 0 };
        return progressUi;
    }

    function updateProgressWidget(message, percent, detailText = "", options = {}) {
        const ui = ensureProgressWidget();
        const baseMessage = String(message || "Working...").replace(/\s+/g, " ").trim();
        const oneLineMessage = activeCourseLabel
            ? `${baseMessage} | Course: ${activeCourseLabel}`
            : baseMessage;
        const oneLineDetail = String(detailText || `${Math.round(ui.percent)}%`).replace(/\s+/g, " ").trim();
        ui.status.textContent = oneLineMessage || "Working...";
        const safePercent = Math.max(0, Math.min(100, Number(percent) || 0));
        const allowDecrease = Boolean(options && options.allowDecrease);
        if (allowDecrease || safePercent >= ui.percent) {
            ui.percent = safePercent;
            ui.bar.style.width = `${safePercent}%`;
        }
        ui.detail.textContent = oneLineDetail || `${Math.round(ui.percent)}%`;
    }

    function setLoadingStatus(message) {
        updateProgressWidget(message || "Loading...", 0, "Loading...", { allowDecrease: true });
    }

    function compactProgressName(pathLike, maxLen = 36) {
        const text = String(pathLike || "").trim();
        if (!text) {
            return "";
        }
        const leaf = text.split(/[\\/]/).filter(Boolean).pop() || text;
        if (leaf.length <= maxLen) {
            return leaf;
        }
        return `${leaf.slice(0, Math.max(8, maxLen - 3))}...`;
    }

    function logStep(step, message, extra = null) {
        if (extra === null || extra === undefined) {
            console.log(`[BB Downloader][${step}] ${message}`);
            return;
        }
        console.log(`[BB Downloader][${step}] ${message}`, extra);
    }

    function logFilesGroupedByContentId(files) {
        const entries = Array.isArray(files) ? files : [];
        const grouped = new Map();

        for (const file of entries) {
            const contentId = String(file?.contentId || "").trim() || "(no-content-id)";
            if (!grouped.has(contentId)) {
                grouped.set(contentId, []);
            }
            grouped.get(contentId).push(String(file?.name || "(unnamed)").trim() || "(unnamed)");
        }

        const mapping = {};
        for (const [contentId, names] of grouped.entries()) {
            mapping[contentId] = names;
            logStep("2/4 Structure", "ContentID file list", {
                contentId,
                fileCount: names.length,
                files: names
            });
        }

        logStep("2/4 Structure", "All contentID to file mappings", mapping);
    }

    function getStripeCustomerId() {
        if (verifiedStripeCustomerId) {
            return verifiedStripeCustomerId;
        }
        const fromStorage = localStorage.getItem("bb_stripe_customer_id");
        return (fromStorage || "").trim();
    }

    function setStripeCustomerId(customerId) {
        verifiedStripeCustomerId = (customerId || "").trim();
        if (verifiedStripeCustomerId) {
            localStorage.setItem("bb_stripe_customer_id", verifiedStripeCustomerId);
        }
    }

    function getWorkerBaseUrl() {
        const fromStorage = String(localStorage.getItem("bb_worker_base_url") || "").trim();
        const baseUrl = fromStorage || DEFAULT_WORKER_BASE_URL;
        if (!baseUrl) {
            throw new Error("Cloudflare Worker URL is not configured. Set localStorage key bb_worker_base_url or update DEFAULT_WORKER_BASE_URL in script.js");
        }
        return baseUrl.replace(/\/+$/, "");
    }

    async function verifyProfileEmailViaBackend(email) {
        const response = await fetch(`${getWorkerBaseUrl()}/verify-profile-email`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                email
            })
        });

        if (!response.ok) {
            const payload = await response.json().catch(() => ({}));
            const reason = payload.error || `HTTP ${response.status}`;
            throw new Error(`Profile verification failed: ${reason}`);
        }

        const payload = await response.json();
        setStripeCustomerId(payload.stripe_customer_id || "");
    }

    function isMeaningfulHtml(html) {
        if (!html || !html.trim()) {
            return false;
        }
        const compact = html.replace(/\s+/g, "").toLowerCase();
        return compact !== "<html><head></head><body></body></html>";
    }

    function extractEmailFromText(value) {
        const text = String(value || "");
        const match = text.match(/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/);
        return match ? String(match[0]).trim().toLowerCase() : "";
    }

    function extractProfileEmailFromHtml(profileHtml) {
        const html = String(profileHtml || "");
        if (!html.trim()) {
            return "";
        }

        try {
            const doc = new DOMParser().parseFromString(html, "text/html");
            const mailto = doc.querySelector('a[href^="mailto:"]');
            const fromMailto = extractEmailFromText(String(mailto?.getAttribute("href") || "").replace(/^mailto:/i, ""));
            if (fromMailto) {
                return fromMailto;
            }

            const visibleText = String(doc.body?.textContent || "");
            const fromVisible = extractEmailFromText(visibleText);
            if (fromVisible) {
                return fromVisible;
            }
        } catch (error) {
            // Fall back to regex-only extraction below.
        }

        return extractEmailFromText(html);
    }

    async function getProfileHtml() {
        const frame = document.createElement("iframe");
        frame.setAttribute("src", PROFILE_URL);
        frame.setAttribute("width", 0);
        frame.setAttribute("height", 0);
        frame.style.display = "none";
        document.body.appendChild(frame);

        try {
            await waitForElementToDisplayinIFrame(frame, "body", 1000, 20000);
            const profileDoc = frame.contentWindow && frame.contentWindow.document;
            const iframeHtml = profileDoc && profileDoc.documentElement ? profileDoc.documentElement.outerHTML : "";
            if (isMeaningfulHtml(iframeHtml)) {
                return iframeHtml;
            }
        } finally {
            frame.remove();
        }

        const response = await fetch(PROFILE_URL, {
            method: "GET",
            credentials: "include"
        });
        if (!response.ok) {
            throw new Error(`Could not fetch profile page: HTTP ${response.status}`);
        }

        const fetchedHtml = await response.text();
        if (!isMeaningfulHtml(fetchedHtml)) {
            throw new Error("Profile HTML is empty, cannot verify email");
        }
        return fetchedHtml;
    }

    async function ensureProfileWhitelisted() {
        logStep("1/4 Guard", "Starting subscription check");
        const profileHtml = await getProfileHtml();
        const profileEmail = extractProfileEmailFromHtml(profileHtml);
        if (!profileEmail) {
            throw new Error("Could not extract email from profile page");
        }
        await verifyProfileEmailViaBackend(profileEmail);
        logStep("1/4 Guard", "Subscription verified");
    }

    function getCourseIdFromUrl(url) {
        if (!url) {
            return "";
        }

        const match = url.match(/\/ultra\/courses\/([^/?#]+)/i);
        if (!match || !match[1]) {
            return "";
        }
        return match[1].trim();
    }

    function extractDatePart(value) {
        const text = String(value || "");
        const match = text.match(/\d{4}-\d{2}-\d{2}/);
        if (match) {
            return match[0];
        }
        return new Date().toISOString().slice(0, 10);
    }

    function toCompactTimestamp(value) {
        const date = value ? new Date(value) : new Date();
        const validDate = Number.isNaN(date.getTime()) ? new Date() : date;
        const yyyy = validDate.getFullYear();
        const mm = String(validDate.getMonth() + 1).padStart(2, "0");
        const dd = String(validDate.getDate()).padStart(2, "0");
        const hh = String(validDate.getHours()).padStart(2, "0");
        const min = String(validDate.getMinutes()).padStart(2, "0");
        const ss = String(validDate.getSeconds()).padStart(2, "0");
        return `${yyyy}${mm}${dd}_${hh}${min}${ss}`;
    }

    async function getBlackboardXsrfToken() {
        if (cachedBlackboardXsrfToken) {
            return cachedBlackboardXsrfToken;
        }

        const fromStorage = (sessionStorage.getItem("xsrf") || localStorage.getItem("xsrf") || "").trim();
        if (fromStorage) {
            cachedBlackboardXsrfToken = fromStorage;
            return cachedBlackboardXsrfToken;
        }
        return cachedBlackboardXsrfToken;
    }

    function looksLikeDownloadUrl(url) {
        if (!url) {
            return false;
        }
        const lower = url.toLowerCase();
        return lower.includes("bbcswebdav") ||
            lower.includes("response-content-disposition=") ||
            lower.includes("response-content-type=application%2fpdf") ||
            lower.includes("/outline/file/") ||
            lower.includes(".xythos.content.blackboardcdn.com/") ||
            lower.endsWith(".pdf");
    }

    function toAbsoluteUrl(url) {
        if (!url) {
            return "";
        }
        try {
            return new URL(url, window.location.origin).href;
        } catch (error) {
            return "";
        }
    }

    function decodeHtmlEntities(value) {
        const text = String(value || "");
        if (!text) {
            return "";
        }
        const textarea = document.createElement("textarea");
        textarea.innerHTML = text;
        return textarea.value;
    }

    function parseBbFileMetadata(rawValue) {
        const decoded = decodeHtmlEntities(rawValue);
        if (!decoded) {
            return null;
        }
        try {
            return JSON.parse(decoded);
        } catch (error) {
            return null;
        }
    }

    function inferFileExtensionFromUrl(url, fallback = ".pdf") {
        const text = String(url || "");
        const match = text.match(/\.([a-z0-9]{2,5})(?:$|[?#])/i);
        if (!match || !match[1]) {
            return fallback;
        }

        const ext = String(match[1]).toLowerCase();
        const allowed = new Set(["pdf", "png", "jpg", "jpeg", "gif", "webp", "bmp", "svg", "tif", "tiff"]);
        if (!allowed.has(ext)) {
            return fallback;
        }
        return `.${ext}`;
    }

    function sanitizeFilenameWithDefaultExt(name, defaultExt = ".pdf", fallbackBase = "file") {
        const cleaned = String(name || "")
            .replace(/[\\/:*?"<>|]+/g, "_")
            .replace(/\s+/g, " ")
            .trim();

        const base = cleaned || String(fallbackBase || "file").trim() || "file";
        if (base.includes(".")) {
            return base;
        }
        return `${base}${defaultExt}`;
    }

    function extractFilesFromBbDocumentHtml(html, currentFolderPath, title, seenUrls, files, contentId = "") {
        if (!html) {
            return 0;
        }

        let added = 0;
        const parsed = new DOMParser().parseFromString(String(html), "text/html");
        const anchors = Array.from(parsed.querySelectorAll("a"));
        for (const anchor of anchors) {
            const href = toAbsoluteUrl(anchor.getAttribute("href") || "");
            const bbMeta = parseBbFileMetadata(anchor.getAttribute("data-bbfile") || "");
            const resourceUrl = toAbsoluteUrl(String(bbMeta?.resourceUrl || bbMeta?.viewerUrl || "").trim());
            const resolvedUrl = resourceUrl || href;

            if (!resolvedUrl || !looksLikeDownloadUrl(resolvedUrl) || seenUrls.has(resolvedUrl)) {
                continue;
            }

            const fileName = sanitizeFilename(String(
                bbMeta?.linkName ||
                bbMeta?.displayName ||
                bbMeta?.alternativeText ||
                anchor.textContent ||
                title ||
                "file"
            ));

            seenUrls.add(resolvedUrl);
            files.push({
                url: resolvedUrl,
                name: `${currentFolderPath}${fileName}`,
                contentId
            });
            added += 1;
        }

        const images = Array.from(parsed.querySelectorAll("img"));
        for (const image of images) {
            const imageUrl = toAbsoluteUrl(image.getAttribute("src") || "");
            if (!imageUrl || !looksLikeDownloadUrl(imageUrl) || seenUrls.has(imageUrl)) {
                continue;
            }

            const imageTitle = String(image.getAttribute("alt") || "").trim() || title || "image";
            const imageExt = inferFileExtensionFromUrl(imageUrl, ".jpg");
            const fileName = sanitizeFilenameWithDefaultExt(imageTitle, imageExt, "image");

            seenUrls.add(imageUrl);
            files.push({
                url: imageUrl,
                name: `${currentFolderPath}${fileName}`,
                contentId
            });
            added += 1;
        }

        return added;
    }

    async function extractFilesFromBbDocumentItem(item, currentFolderPath, title, seenUrls, files, contentId = "") {
        const bodyRaw = String(item?.body?.rawText || "");
        const bodyDisplay = String(item?.body?.displayText || "");
        const inlineHtmlAdded = extractFilesFromBbDocumentHtml(bodyRaw || bodyDisplay, currentFolderPath, title, seenUrls, files, contentId);
        if (inlineHtmlAdded > 0) {
            return;
        }

        const webLocation = toAbsoluteUrl(String(item?.body?.webLocation || "").trim());
        if (!webLocation) {
            return;
        }

        try {
            const xsrf = await getBlackboardXsrfToken();
            const headers = {
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
            };
            if (xsrf) {
                headers["x-blackboard-xsrf"] = xsrf;
            }

            const response = await fetch(webLocation, {
                method: "GET",
                headers,
                credentials: "include"
            });
            if (!response.ok) {
                logStep("2/4 Structure", "x-bb-document webLocation fetch failed", {
                    title,
                    webLocation,
                    status: response.status
                });
                return;
            }

            const webHtml = await response.text();
            const fromWebLocation = extractFilesFromBbDocumentHtml(webHtml, currentFolderPath, title, seenUrls, files, contentId);
            if (fromWebLocation > 0) {
                logStep("2/4 Structure", "Extracted document attachments from webLocation", {
                    title,
                    count: fromWebLocation
                });
            }
        } catch (error) {
            logStep("2/4 Structure", "x-bb-document webLocation parse failed", {
                title,
                webLocation
            });
        }
    }

    async function learnApiFetch(path, queryParams = {}) {
        const xsrf = await getBlackboardXsrfToken();

        const url = new URL(`/learn/api/v1/${path.replace(/^\//, "")}`, window.location.origin);
        for (const [key, value] of Object.entries(queryParams)) {
            url.searchParams.set(key, String(value));
        }

        const headers = {
            "Accept": "application/json, text/plain, */*"
        };
        if (xsrf) {
            headers["x-blackboard-xsrf"] = xsrf;
        }

        const response = await fetch(url.toString(), {
            method: "GET",
            headers,
            credentials: "include"
        });

        if (!response.ok) {
            throw new Error(`Learn API failed: HTTP ${response.status}`);
        }

        return response.json();
    }

    async function learnPublicApiFetch(path, queryParams = {}) {
        const xsrf = await getBlackboardXsrfToken();

        const url = new URL(`/learn/api/public/v1/${path.replace(/^\//, "")}`, window.location.origin);
        for (const [key, value] of Object.entries(queryParams)) {
            url.searchParams.set(key, String(value));
        }

        const headers = {
            "Accept": "application/json, text/plain, */*"
        };
        if (xsrf) {
            headers["x-blackboard-xsrf"] = xsrf;
        }

        const response = await fetch(url.toString(), {
            method: "GET",
            headers,
            credentials: "include"
        });

        if (!response.ok) {
            throw new Error(`Learn Public API failed: HTTP ${response.status}`);
        }

        return response.json();
    }

    function toSafePositiveInt(value, fallback) {
        const parsed = Number.parseInt(String(value), 10);
        if (!Number.isFinite(parsed) || parsed <= 0) {
            return fallback;
        }
        return parsed;
    }

    function resolveNextOffsetFromPaging(payload, currentOffset, currentLimit, itemCount) {
        const nextPage = String(payload?.paging?.nextPage || "").trim();
        if (nextPage) {
            try {
                const nextUrl = new URL(nextPage, window.location.origin);
                const rawOffset = nextUrl.searchParams.get("offset");
                const parsedOffset = Number.parseInt(String(rawOffset || ""), 10);
                if (Number.isFinite(parsedOffset) && parsedOffset >= 0) {
                    return parsedOffset;
                }
            } catch (error) {
                // Fall back to count-based paging below.
            }
        }

        if (itemCount >= currentLimit) {
            return currentOffset + itemCount;
        }
        return -1;
    }

    async function mapWithConcurrency(items, limit, mapper) {
        const list = Array.isArray(items) ? items : [];
        const workerCount = Math.max(1, Math.min(Number(limit) || 1, list.length || 1));
        const results = new Array(list.length);
        let cursor = 0;

        async function worker() {
            while (true) {
                const index = cursor;
                cursor += 1;
                if (index >= list.length) {
                    return;
                }
                results[index] = await mapper(list[index], index);
            }
        }

        await Promise.all(Array.from({ length: workerCount }, () => worker()));
        return results;
    }

    async function fetchAllLearnApiItems(path, baseQueryParams = {}) {
        const limit = toSafePositiveInt(baseQueryParams?.limit, 200);
        let offset = toSafePositiveInt(baseQueryParams?.offset, 0);
        const allItems = [];

        while (true) {
            const queryParams = {
                ...baseQueryParams,
                limit: String(limit),
                offset: String(offset)
            };

            const payload = await learnApiFetch(path, queryParams);
            const items = Array.isArray(payload?.results)
                ? payload.results
                : (Array.isArray(payload) ? payload : []);

            allItems.push(...items);

            const nextOffset = resolveNextOffsetFromPaging(payload, offset, limit, items.length);
            if (nextOffset < 0 || nextOffset === offset || items.length === 0) {
                break;
            }
            offset = nextOffset;
        }

        return allItems;
    }

    async function fetchAllContentAttachments(courseId, contentId) {
        const limit = 200;
        let offset = 0;
        const allAttachments = [];

        while (true) {
            const payload = await learnPublicApiFetch(`courses/${courseId}/contents/${contentId}/attachments`, {
                limit: String(limit),
                offset: String(offset)
            });

            const attachments = Array.isArray(payload?.results)
                ? payload.results
                : (Array.isArray(payload) ? payload : []);

            allAttachments.push(...attachments);

            const nextOffset = resolveNextOffsetFromPaging(payload, offset, limit, attachments.length);
            if (nextOffset < 0 || nextOffset === offset || attachments.length === 0) {
                break;
            }
            offset = nextOffset;
        }

        return allAttachments;
    }

    function pickAttachmentDirectUrl(attachment) {
        const candidates = [
            attachment?.downloadUrl,
            attachment?.resourceUrl,
            attachment?.permanentUrl,
            attachment?.url,
            attachment?.link,
            attachment?.links?.download,
            attachment?.links?.resource,
            attachment?.links?.self?.href,
            attachment?.body?.downloadUrl
        ];

        for (const candidate of candidates) {
            const absolute = toAbsoluteUrl(String(candidate || "").trim());
            if (absolute && looksLikeDownloadUrl(absolute)) {
                return absolute;
            }
        }
        return "";
    }

    async function resolveAttachmentDownloadUrl(courseId, contentId, attachmentId) {
        if (!courseId || !contentId || !attachmentId) {
            return "";
        }

        const xsrf = await getBlackboardXsrfToken();
        const endpoint = new URL(
            `/learn/api/public/v1/courses/${encodeURIComponent(courseId)}/contents/${encodeURIComponent(contentId)}/attachments/${encodeURIComponent(attachmentId)}/download`,
            window.location.origin
        );

        const headers = {
            "Accept": "*/*"
        };
        if (xsrf) {
            headers["x-blackboard-xsrf"] = xsrf;
        }

        try {
            const response = await fetch(endpoint.toString(), {
                method: "GET",
                headers,
                credentials: "include",
                redirect: "manual"
            });

            if (response.status >= 300 && response.status < 400) {
                const location = toAbsoluteUrl(response.headers.get("location") || "");
                if (location) {
                    return location;
                }
            }
        } catch (error) {
            // Continue to non-download route fallback below.
        }

        try {
            const legacyEndpoint = new URL(
                `/learn/api/public/v1/courses/${encodeURIComponent(courseId)}/contents/${encodeURIComponent(contentId)}/attachments/${encodeURIComponent(attachmentId)}`,
                window.location.origin
            );
            const legacyResponse = await fetch(legacyEndpoint.toString(), {
                method: "GET",
                headers,
                credentials: "include",
                redirect: "manual"
            });
            const legacyRedirectedUrl = toAbsoluteUrl(legacyResponse.headers.get("location") || "");
            if (legacyRedirectedUrl && looksLikeDownloadUrl(legacyRedirectedUrl)) {
                return legacyRedirectedUrl;
            }
        } catch (legacyError) {
            // Fall through to structured logging below.
        }

        try {
            const resolvedViaBackground = await resolveUrlViaBackgroundFetch(endpoint.toString());
            if (resolvedViaBackground && looksLikeDownloadUrl(resolvedViaBackground)) {
                return resolvedViaBackground;
            }
        } catch (bgError) {
            // Fall through to structured logging below.
        }

        logStep("2/4 Structure", "Attachment download URL resolve failed", {
            courseId,
            contentId,
            attachmentId
        });

        return "";
    }

    async function collectFilesFromContentAttachments(courseId, contentId, currentFolderPath, title) {
        const normalizedContentId = String(contentId || "").trim();
        if (!courseId || !normalizedContentId) {
            return [];
        }

        let attachments;
        try {
            attachments = await fetchAllContentAttachments(courseId, normalizedContentId);
        } catch (error) {
            return [];
        }

        const candidates = await mapWithConcurrency(attachments, 8, async (attachment) => {
            const attachmentId = String(attachment?.id || attachment?.attachmentId || "").trim();
            let resolvedUrl = pickAttachmentDirectUrl(attachment);
            if (!resolvedUrl && attachmentId) {
                resolvedUrl = await resolveAttachmentDownloadUrl(courseId, normalizedContentId, attachmentId);
            }

            if (!resolvedUrl) {
                return null;
            }

            const filename = sanitizeFilename(String(
                attachment?.fileName ||
                attachment?.name ||
                attachment?.displayName ||
                title ||
                "file"
            ));

            return {
                url: resolvedUrl,
                name: `${currentFolderPath}${filename}`,
                contentId: normalizedContentId
            };
        });

        return candidates.filter(Boolean);
    }

    async function discoverCourseFilesViaLearnApi(courseId, includeChildren) {
        logStep("2/4 Structure", "Fetching Learn API content tree", { courseId, includeChildren });
        const defaultQueryParams = {
            "@view": "Summary",
            "expand": "assignedGroups,selfEnrollmentGroups.group,gradebookCategory",
            "includeInActivityTracking": "true",
            "limit": "200",
            "recursive": false
        };
        const bbPageChildrenQueryParams = {
            "expand": "assignedGroups,selfEnrollmentGroups.group",
            "limit": "200",
            "offset": "0",
            "recursive": false
        };
        const queue = [{
            path: `courses/${courseId}/contents/ROOT/children`,
            folderPath: "",
            queryParams: defaultQueryParams
        }];
        const seenPaths = new Set();
        const seenUrls = new Set();
        const files = [];
        const folders = new Set();
        const discoveredResources = new Map();

        while (queue.length > 0) {
            console.log(JSON.stringify(queue));
            const current = queue.shift();
            if (!current || seenPaths.has(current.path)) {
                continue;
            }
            seenPaths.add(current.path);

            const items = await fetchAllLearnApiItems(current.path, current.queryParams || defaultQueryParams);

            for (const item of items) {
                const title = String(item?.title || item?.name || "file").trim();
                const handler = String(item?.contentHandler || "");
                const currentFolderPath = current.folderPath || "";
                const itemId = String(item?.id || "").trim();

                if (itemId && !discoveredResources.has(itemId)) {
                    discoveredResources.set(itemId, {
                        contentId: itemId,
                        title,
                        folderPath: currentFolderPath
                    });
                }

                if (handler === "resource/x-bb-file") {
                    const fileInfo = item?.contentDetail?.["resource/x-bb-file"]?.file || {};
                    const preferredName = sanitizeFilename(String(fileInfo?.fileName || title || "file.pdf"));
                    const fullFileName = `${currentFolderPath}${preferredName}`;

                    const permanentAbsoluteUrl = toAbsoluteUrl(String(fileInfo?.permanentUrl || "").trim());
                    if (permanentAbsoluteUrl && looksLikeDownloadUrl(permanentAbsoluteUrl) && !seenUrls.has(permanentAbsoluteUrl)) {
                        seenUrls.add(permanentAbsoluteUrl);
                        files.push({
                            url: permanentAbsoluteUrl,
                            name: fullFileName,
                            contentId: itemId
                        });
                    }
                }

                if (handler === "resource/x-bb-externallink") {
                    const externalInfo = item?.contentDetail?.["resource/x-bb-externallink"] || {};
                    const externalUrl = toAbsoluteUrl(String(externalInfo?.url || "").trim());
                    if (externalUrl) {
                        const shortcutName = sanitizeShortcutFilename(String(title || "link"));
                        files.push({
                            url: externalUrl,
                            name: `${currentFolderPath}${shortcutName}`,
                            inlineText: createInternetShortcutContent(externalUrl),
                            contentId: itemId
                        });
                    }
                }
                
                if (handler === "resource/x-bb-document" || handler === "resource/x-bb-image") {
                    await extractFilesFromBbDocumentItem(item, currentFolderPath, title, seenUrls, files, itemId);
                }

                const isFolder = Boolean(item?.contentDetail?.[handler]?.isFolder) ||
                    Boolean(item?.isFolder) ||
                    handler === "resource/x-bb-folder";
                const isBbPage = Boolean(item?.contentDetail?.[handler]?.isBbPage);
                const folderName = sanitizeFolderName(title, "folder");
                const nextFolderPath = `${currentFolderPath}${folderName}/`;
                if (isFolder) {
                    folders.add(nextFolderPath);
                    // console.log("Discovered folder", nextFolderPath);
                }
                
                if (includeChildren) {
                    const hasChildren = isBbPage || isFolder || Boolean(item?.hasChildren || item?.hasChildrenItems || item?.hasChildrenItemsAvailable);
                    console.log("Item", title, "is folder?", isFolder, "isBbPage?", isBbPage, "has children?", hasChildren, "id", itemId, "data", JSON.stringify(item));
                    if (hasChildren && itemId) {
                        queue.push({
                            path: `courses/${courseId}/contents/${itemId}/children`,
                            folderPath: isFolder ? nextFolderPath : currentFolderPath,
                            queryParams: isBbPage ? bbPageChildrenQueryParams : defaultQueryParams
                        });
                    }
                }
            }
        }

        const discoveredResourceList = Array.from(discoveredResources.values());
        const attachmentResults = await mapWithConcurrency(discoveredResourceList, 6, async (resource) => {
            const filesFromAttachments = await collectFilesFromContentAttachments(
                courseId,
                resource.contentId,
                resource.folderPath,
                resource.title
            );
            return {
                resource,
                filesFromAttachments
            };
        });

        for (const result of attachmentResults) {
            const resource = result && result.resource ? result.resource : null;
            const filesFromAttachments = Array.isArray(result?.filesFromAttachments) ? result.filesFromAttachments : [];
            let attachmentApiHits = 0;
            for (const attachmentFile of filesFromAttachments) {
                if (!attachmentFile?.url || seenUrls.has(attachmentFile.url)) {
                    continue;
                }
                seenUrls.add(attachmentFile.url);
                files.push(attachmentFile);
                attachmentApiHits += 1;
            }

            logStep("2/4 Structure", "Attachment API check complete for content", {
                title: String(resource?.title || "file"),
                itemId: String(resource?.contentId || ""),
                found: attachmentApiHits
            });
        }

        logStep("2/4 Structure", "Learn API discovery complete", {
            folderCount: folders.size,
            fileCount: files.length,
            visitedNodes: seenPaths.size
        });
        logFilesGroupedByContentId(files);

        return { files, folders: Array.from(folders) };
    }

    async function buildCourseRootFolder(baseUrl) {
        const courseId = getCourseIdFromUrl(baseUrl);
        if (!courseId) {
            return `course_${toCompactTimestamp("")}`;
        }

        let courseCode = courseId;
        let timestamp = toCompactTimestamp("");

        try {
            const payload = await learnApiFetch(`courses/${courseId}`, {});
            courseCode = String(payload?.courseId || courseId).trim() || courseId;
            timestamp = toCompactTimestamp(
                payload?.modified || payload?.created || payload?.createdDate || payload?.lastAccessed || ""
            );
        } catch (error) {
            logStep("2/4 Structure", "Course metadata fetch failed, using fallback root folder", { courseId });
        }

        const safeCourseCode = sanitizeFolderName(courseCode, "course");
        return `${safeCourseCode}_${timestamp}`;
    }

    async function extractViaBackend(baseUrl) {
        const courseId = getCourseIdFromUrl(baseUrl);
        if (!courseId) {
            throw new Error("Could not detect course id from current URL");
        }

        logStep("2/4 Structure", "Resolving course file structure", { courseId });

        const discovered = await discoverCourseFilesViaLearnApi(courseId, ENABLE_FOLDER_TRAVERSAL);
        return { pdfs: discovered.files, folders: discovered.folders };
    }

    function sleep(ms) {
        return new Promise((resolve) => setTimeout(resolve, ms));
    }

    function normalizeUrlKey(url) {
        if (!url) {
            return "";
        }
        return url.split("#")[0];
    }

    function sanitizeFilename(name, fallback = "file.pdf") {
        const cleaned = (name || "")
            .replace(/[\\/:*?"<>|]+/g, "_")
            .replace(/\s+/g, " ")
            .trim();
        const candidate = cleaned || fallback;
        if (candidate.includes(".")) {
            return candidate;
        }
        return `${candidate}.pdf`;
    }

    function sanitizeFolderName(name, fallback = "folder") {
        const cleaned = (name || "")
            .replace(/[\\/:*?"<>|]+/g, "_")
            .replace(/\s+/g, " ")
            .trim();
        return cleaned || fallback;
    }

    function sanitizeShortcutFilename(name, fallback = "link") {
        const base = sanitizeFolderName(name, fallback);
        return /\.url$/i.test(base) ? base : `${base}.url`;
    }

    function createInternetShortcutContent(url) {
        const target = String(url || "").trim();
        return `[InternetShortcut]\r\nURL=${target}\r\n`;
    }

    function sanitizeZipPath(path, isFolder = false) {
        const normalized = String(path || "").replace(/\\+/g, "/").trim();
        const segments = normalized.split("/").filter(Boolean).map((segment) => {
            const cleaned = segment
                .replace(/[:*?"<>|]+/g, "_")
                .replace(/\s+/g, " ")
                .trim();
            return cleaned || (isFolder ? "folder" : "file");
        });

        if (segments.length === 0) {
            return isFolder ? "folder/" : "file.pdf";
        }

        if (!isFolder) {
            const last = segments.length - 1;
            if (!segments[last].includes(".")) {
                segments[last] = `${segments[last]}.pdf`;
            }
        }

        const joined = segments.join("/");
        return isFolder ? `${joined}/` : joined;
    }

    function buildOutputPath(relativePath, isFolder = false) {
        if (!String(relativePath || "").trim()) {
            return "";
        }
        return sanitizeZipPath(relativePath, isFolder).replace(/^\/+/, "");
    }

    function isOutlineViewerUrl(url) {
        if (!url) {
            return false;
        }
        return /\/ultra\/courses\/[^/]+\/outline\/file\//i.test(url);
    }

    function isBbcswebdavUrl(url) {
        if (!url) {
            return false;
        }
        return /\/bbcswebdav\//i.test(url);
    }

    function isPdfFilename(name) {
        return /\.pdf$/i.test(String(name || "").trim());
    }

    function isSameOriginUrl(url) {
        try {
            return new URL(url, window.location.origin).origin === window.location.origin;
        } catch (error) {
            return false;
        }
    }

    function shouldOmitCredentialsForUrl(url) {
        const raw = String(url || "");
        const lower = raw.toLowerCase();
        return lower.includes("xythos.content.blackboardcdn.com") ||
            lower.includes("x-amz-signature=") ||
            lower.includes("x-blackboard-signature=");
    }

    function sendRuntimeMessage(message) {
        return new Promise((resolve, reject) => {
            if (!chrome || !chrome.runtime || !chrome.runtime.sendMessage) {
                resolve({});
                return;
            }

            chrome.runtime.sendMessage(message, (response) => {
                if (chrome.runtime.lastError) {
                    reject(new Error(chrome.runtime.lastError.message));
                    return;
                }
                resolve(response || {});
            });
        });
    }

    async function resolveSignedUrlViaManualRedirect(sourceUrl) {
        const response = await fetch(sourceUrl, {
            method: "GET",
            credentials: "include",
            redirect: "manual"
        });

        const location = response.headers.get("location");
        if (!location) {
            return sourceUrl;
        }
        return toAbsoluteUrl(location) || sourceUrl;
    }

    async function resolveUrlViaBackgroundFetch(sourceUrl) {
        const payload = await sendRuntimeMessage({ type: "resolveUrlForBackend", sourceUrl });
        const candidate = toAbsoluteUrl(String(payload?.url || "").trim());
        return candidate || sourceUrl;
    }

    function buildPdfNameMapFromDocument(doc, baseUrl) {
        const mapping = new Map();
        const anchors = Array.from(doc.querySelectorAll("a[href*='bbcswebdav']"));

        for (const anchor of anchors) {
            const rawHref = anchor.getAttribute("href") || "";
            if (!rawHref) {
                continue;
            }

            const absoluteHref = new URL(rawHref, baseUrl).href;
            const key = normalizeUrlKey(absoluteHref);
            if (!key || mapping.has(key)) {
                continue;
            }

            const visibleText = (anchor.textContent || "").trim();
            if (!visibleText) {
                continue;
            }

            mapping.set(key, sanitizeFilename(visibleText));
        }

        return mapping;
    }

    function isClickableFolderToggle(el) {
        if (!el || typeof el.getAttribute !== "function") {
            return false;
        }

        if (el.disabled) {
            return false;
        }

        const tag = (el.tagName || "").toUpperCase();
        if (tag === "A") {
            const href = (el.getAttribute("href") || "").trim().toLowerCase();
            if (href && href !== "#" && !href.startsWith("javascript:")) {
                return false;
            }
        }

        const expanded = (el.getAttribute("aria-expanded") || "").toLowerCase();
        if (expanded === "true") {
            return false;
        }

        return true;
    }

    function getFolderToggleCandidates(doc) {
        const contentRoot = doc.querySelector("ul#content_listContainer, [data-testid='course-content-list'], .course-content");
        if (!contentRoot) {
            return [];
        }

        const selectors = [
            '[aria-expanded="false"]',
            '[role="button"][aria-expanded]',
            '.collapse-control',
            '.expand-control',
            '[data-toggle="collapse"]',
            '[data-bb-toggle="collapse"]'
        ];

        const unique = new Set();
        const results = [];
        for (const selector of selectors) {
            for (const node of Array.from(contentRoot.querySelectorAll(selector))) {
                if (!unique.has(node)) {
                    unique.add(node);
                    results.push(node);
                }
            }
        }

        return results;
    }

    async function expandAllFoldersInDocument(doc) {
        const maxRounds = 4;
        for (let round = 0; round < maxRounds; round++) {
            const candidates = getFolderToggleCandidates(doc);
            let clicked = 0;

            for (const el of candidates) {
                if (!isClickableFolderToggle(el)) {
                    continue;
                }

                try {
                    el.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true }));
                    clicked += 1;
                } catch (error) {
                    console.log("Folder expansion click failed", error);
                }
            }

            if (clicked === 0) {
                return;
            }

            await sleep(1200);
        }
    }

    function waitForElementToDisplay(doc, selector, checkFrequencyInMs, timeoutInMs) {
        return new Promise(
            (resolve, reject) => {
                var startTimeInMs = Date.now();
                (function loopSearch() {
                if (doc.querySelector(selector) != null) {
                    resolve(true);
                    return true;
                }
                else {
                    setTimeout(function () {
                        if (timeoutInMs && Date.now() - startTimeInMs > timeoutInMs)
                            resolve(false);
                        loopSearch();
                    }, checkFrequencyInMs);
                }
            })();
        }
      )
    }
    function waitForElementToDisplayinIFrame(iframe, selector, checkFrequencyInMs, timeoutInMs) {
        return new Promise(
            (resolve, reject) => {
                var startTimeInMs = Date.now();
                (function loopSearch() {
                try {
                    if (iframe.contentWindow.document.querySelector(selector) != null) {
                        resolve(true);
                        return true;
                    }
                    else {
                        setTimeout(function () {
                            if (timeoutInMs && Date.now() - startTimeInMs > timeoutInMs)
                                resolve(false);
                            loopSearch();
                        }, checkFrequencyInMs);
                    }
                } catch (error) {
                    setTimeout(function () {
                        if (timeoutInMs && Date.now() - startTimeInMs > timeoutInMs)
                            resolve(false);
                        loopSearch();
                    }, checkFrequencyInMs);
                }
            })();
        }
      )
    }

	const model = (() => {

		let zipWriter;
		return {
            addFolder(folderName) {
                if (!zipWriter) {
                    zipWriter = new zip.ZipWriter(new zip.BlobWriter("application/zip"), { bufferedWrite: true });
                }
                const normalized = folderName.endsWith("/") ? folderName : `${folderName}/`;
                return zipWriter.add(normalized, new zip.TextReader(""));
            },
			addFile(file, options) {
				if (!zipWriter) {
					zipWriter = new zip.ZipWriter(new zip.BlobWriter("application/zip"), { bufferedWrite: true });
				}
                console.log("Adding file", file.name)
				return zipWriter.add(file.name, new zip.BlobReader(file), options);
			},
			async getBlobURL() {
				if (zipWriter) {
					const blobURL = URL.createObjectURL(await zipWriter.close());
					zipWriter = null;
					return blobURL;
				} else {
					throw new Error("Zip file closed");
				}
			}
		};

	})();



    async function addFolders(folders) {
        logStep("3/4 Zip", "Adding folders to ZIP", { count: folders.length });
        for (const folder of folders) {
            try {
                await model.addFolder(folder);
            } catch (error) {
                console.log("Failed to add folder to ZIP", folder, error);
            }
        }
    }

    async function addFiles(files) {
        logStep("3/4 Zip", "Adding files to ZIP", { count: files.length });
        await Promise.all(Array.from(files).map(async file => {
            const controller = new AbortController();
            const signal = controller.signal;
            try {
                const entry = await model.addFile(file);
                console.log(`Last modification date: ${entry.lastModDate.toLocaleString()}\n  Compressed size: ${entry.compressedSize.toLocaleString()} bytes`);
            } catch (error) {
                if (!(signal.reason && signal.reason.code == error.code)) {
                    console.log(error)
                }
            }
        }));
    }

    async function downloadZip(filename) {
        logStep("4/4 Download", "Preparing final ZIP download", { filename });
        let blobURL;
        try {
            blobURL = await model.getBlobURL();
        } catch (error) {
            alert(error);
        }
        if (blobURL) {
            const anchor = document.createElement("a");
            const clickEvent = new MouseEvent("click");
            anchor.href = blobURL;
            anchor.download = filename;
            anchor.dispatchEvent(clickEvent);
        }
    }

    async function resolveDownloadUrl(child) {
        let downloadUrl = child.href;
        if (isBbcswebdavUrl(downloadUrl)) {
            // Keep resolution non-navigational to avoid browser-triggered direct downloads.
            const manualResolved = await resolveSignedUrlViaManualRedirect(downloadUrl);
            downloadUrl = isBbcswebdavUrl(manualResolved)
                ? await resolveUrlViaBackgroundFetch(downloadUrl)
                : manualResolved;
        }
        return downloadUrl;
    }

    async function resolveDownloadTasks(children, onProgress = null, concurrency = 6) {
        const allChildren = Array.from(children || []);
        const parallelCandidates = [];
        const outlineCandidates = [];
        const resolvedTasks = [];
        const total = allChildren.length;
        let completed = 0;

        for (const child of allChildren) {
            if (isOutlineViewerUrl(child && child.href)) {
                outlineCandidates.push(child);
            } else {
                parallelCandidates.push(child);
            }
        }

        const emitProgress = (name = "") => {
            if (typeof onProgress === "function") {
                onProgress(completed, total, name);
            }
        };

        let index = 0;
        async function worker() {
            while (true) {
                const currentIndex = index;
                index += 1;
                if (currentIndex >= parallelCandidates.length) {
                    return;
                }

                const child = parallelCandidates[currentIndex];
                try {
                    if (typeof child.inlineText === "string" && child.inlineText.length > 0) {
                        resolvedTasks.push({
                            downloadUrl: "",
                            filename: child.filename,
                            inlineText: child.inlineText
                        });
                        continue;
                    }

                    const downloadUrl = await resolveDownloadUrl(child);
                    if (looksLikeDownloadUrl(downloadUrl)) {
                        resolvedTasks.push({ downloadUrl, filename: child.filename });
                    }
                } catch (error) {
                    console.log("child.href", error);
                } finally {
                    completed += 1;
                    emitProgress(child && child.filename ? child.filename : "");
                }
            }
        }

        const workerCount = Math.max(1, Math.min(concurrency, parallelCandidates.length || 1));
        await Promise.all(Array.from({ length: workerCount }, () => worker()));

        // Do not iframe-resolve outline URLs on frontend to avoid browser-triggered downloads.
        for (const child of outlineCandidates) {
            try {
                const downloadUrl = String(child && child.href ? child.href : "").trim();
                if (looksLikeDownloadUrl(downloadUrl)) {
                    resolvedTasks.push({ downloadUrl, filename: child.filename });
                }
            } catch (error) {
                console.log("child.href", error);
            } finally {
                completed += 1;
                emitProgress(child && child.filename ? child.filename : "");
            }
        }

        return {
            tasks: resolvedTasks,
            total,
            outlineCount: outlineCandidates.length,
            parallelCount: parallelCandidates.length
        };
    }

    async function downloadBlobsInParallel(tasks, concurrency = 4, onProgress = null) {
        const fileBlobs = [];
        let index = 0;
        let completed = 0;

        async function worker() {
            while (true) {
                const currentIndex = index;
                index += 1;
                if (currentIndex >= tasks.length) {
                    return;
                }

                const task = tasks[currentIndex];
                try {
                    if (typeof task.inlineText === "string" && task.inlineText.length > 0) {
                        const inlineBlob = new Blob([task.inlineText], { type: "text/plain;charset=utf-8" });
                        fileBlobs.push(new File([inlineBlob], task.filename));
                        completed += 1;
                        if (typeof onProgress === "function") {
                            onProgress(completed, tasks.length, task.filename);
                        }
                        continue;
                    }

                    let requestUrl = task.downloadUrl;
                    console.log(`[BB Downloader][3/4 Zip] Fetching file`, { filename: task.filename, url: requestUrl });

                    const response = await fetch(requestUrl, {
                        method: "GET",
                        credentials: shouldOmitCredentialsForUrl(requestUrl) ? "omit" : "include"
                    });
                    const blob = await response.blob();
                    fileBlobs.push(new File([blob], task.filename));
                    completed += 1;
                    if (typeof onProgress === "function") {
                        onProgress(completed, tasks.length, task.filename);
                    }
                    logStep("3/4 Zip", "Downloaded file blob", { name: task.filename });
                } catch (error) {
                    console.log("child.href", error);
                }
            }
        }

        const workerCount = Math.max(1, Math.min(concurrency, tasks.length));
        await Promise.all(Array.from({ length: workerCount }, () => worker()));
        return fileBlobs;
    }

    const extractLinks = async (doc=null, directory="", iframe=null) => {
        let sourceDoc = doc;
        if (sourceDoc == null) {
            const loaded = await waitForElementToDisplayinIFrame(iframe, "ul#content_listContainer", 1000, 15000);
            if (!loaded) return [];
            sourceDoc = iframe.contentWindow.document;
        }

        const baseUrl = sourceDoc.location ? sourceDoc.location.href : window.location.href;
        const pagePdfNameMap = buildPdfNameMapFromDocument(sourceDoc, baseUrl);
        const pageKey = baseUrl.split("#")[0];
        if (visitedPageUrls.has(pageKey)) {
            return [];
        }
        visitedPageUrls.add(pageKey);

        const parsed = await extractViaBackend(baseUrl);
        logStep("2/4 Structure", "Received file structure", {
            folderCount: (parsed.folders || []).length,
            fileCount: (parsed.pdfs || []).length
        });
        for (const folder of (parsed.folders || [])) {
            const normalized = String(folder || "").trim();
            if (!normalized) {
                continue;
            }
            zipFolders.add(buildOutputPath(normalized, true));
        }

        const results = [];
        for (const pdf of parsed.pdfs || []) {
            if (!pdf.url || visitedFileUrls.has(pdf.url)) {
                continue;
            }
            visitedFileUrls.add(pdf.url);

            const pdfUrlKey = normalizeUrlKey(pdf.url);
            const apiPathName = String(pdf.name || "");
            const shouldUsePageName = !apiPathName.includes("/") && pagePdfNameMap.has(pdfUrlKey);
            const preferredName = shouldUsePageName ? pagePdfNameMap.get(pdfUrlKey) : (apiPathName || "file.pdf");
            results.push({
                href: pdf.url,
                filename: buildOutputPath(directory + sanitizeZipPath(preferredName, false), false),
                inlineText: typeof pdf.inlineText === "string" ? pdf.inlineText : "",
                contentId: String(pdf.contentId || "").trim()
            });
        }

        return results;
    }

    function removeDuplicateFilenames(entries) {
        const seen = new Set();
        const unique = [];
        for (const entry of entries || []) {
            const key = String(entry?.filename || "").trim().toLowerCase();
            if (!key || seen.has(key)) {
                continue;
            }
            seen.add(key);
            unique.push(entry);
        }
        return unique;
    }

    function isCourseScreenUrl(url) {
        const text = String(url || "");
        return /\/ultra\/courses\/[^/?#]+/i.test(text);
    }

    function isElementVisible(el) {
        if (!el) {
            return false;
        }
        const rect = el.getBoundingClientRect();
        const style = window.getComputedStyle(el);
        return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden";
    }

    function isCourseScreenReady() {
        if (!isCourseScreenUrl(window.location.href)) {
            return false;
        }

        if (document.readyState !== "complete") {
            return false;
        }

        const initialLoadArea = document.getElementById("initial-load-area");
        if (initialLoadArea) {
            const style = window.getComputedStyle(initialLoadArea);
            const stillVisible = style.display !== "none" && style.visibility !== "hidden" && style.opacity !== "0";
            const fadedOut = initialLoadArea.classList.contains("fade-out");
            if (stillVisible && !fadedOut) {
                return false;
            }
        }

        // If this is a course page and initial loading overlay is gone, show button.
        // Placement logic will anchor in header when available, otherwise fallback to bottom-right.
        return true;
    }

    function findCourseContentHeadingElement() {
        if (courseContentHeadingAnchor && courseContentHeadingAnchor.isConnected && isElementVisible(courseContentHeadingAnchor)) {
            return courseContentHeadingAnchor;
        }

        const candidates = Array.from(document.querySelectorAll("h1, h2, h3, [role='heading'], span, div"));
        const matched = [];
        for (const el of candidates) {
            const text = String(el && el.textContent ? el.textContent : "").replace(/\s+/g, " ").trim();
            if (text === "Course Content" && isElementVisible(el)) {
                matched.push(el);
            }
        }

        if (matched.length === 0) {
            return null;
        }

        matched.sort((a, b) => a.getBoundingClientRect().top - b.getBoundingClientRect().top);
        courseContentHeadingAnchor = matched[0];
        return courseContentHeadingAnchor;
    }

    function findCourseContentActionContainer() {
        const strict = document.querySelector("#site-wrap > div.inner-wrap > section > div > div > main > div > section > div > div.course-outline-grid > div > react-course-content-header > div > header > div");
        if (strict && isElementVisible(strict)) {
            return strict;
        }

        const broad = document.querySelector("react-course-content-header header > div, react-course-content-header header");
        if (broad && isElementVisible(broad)) {
            return broad;
        }

        return null;
    }

    function placeDownloadButtonNearCourseContent(button) {
        const actionContainer = findCourseContentActionContainer();
        if (actionContainer && actionContainer.parentElement) {
            actionContainer.parentElement.style.marginInlineEnd = "0";
            if (button.parentElement !== actionContainer) {
                actionContainer.appendChild(button);
            }

            button.style.position = "static";
            button.style.right = "";
            button.style.bottom = "";
            button.style.top = "";
            button.style.transform = "";
            button.style.marginLeft = "12px";
            button.style.marginTop = "0";
            button.style.verticalAlign = "middle";
            button.style.display = "inline-flex";
            button.style.alignItems = "center";
            button.style.zIndex = "1";
            return true;
        }

        if (button.parentElement !== document.body) {
            document.body.appendChild(button);
        }
        if (button.parentElement) {
            button.parentElement.style.marginInlineEnd = "0";
        }

        let fallbackBottomPx = 16;
        if (progressUi && progressUi.container && progressUi.container.isConnected) {
            const widgetStyle = window.getComputedStyle(progressUi.container);
            const widgetVisible = widgetStyle.display !== "none" && widgetStyle.visibility !== "hidden";
            if (widgetVisible) {
                const widgetHeight = Math.ceil(progressUi.container.getBoundingClientRect().height || 0);
                fallbackBottomPx = 16 + widgetHeight + 12;
            }
        }

        button.style.position = "fixed";
        button.style.right = "16px";
        button.style.bottom = `${fallbackBottomPx}px`;
        button.style.top = "";
        button.style.transform = "";
        button.style.marginLeft = "0";
        button.style.marginTop = "0";
        button.style.verticalAlign = "";
        button.style.display = "inline-flex";
        button.style.alignItems = "center";
        button.style.zIndex = "2147483647";
        return true;
    }

    function ensureDownloadAllButton() {
        if (downloadAllButton && document.body.contains(downloadAllButton)) {
            return downloadAllButton;
        }

        const button = document.createElement("button");
        button.type = "button";
        button.textContent = "Download all";
        button.style.zIndex = "1000";
        button.style.padding = "12px 20px";
        button.style.borderRadius = "12px";
        button.style.border = "2px solid #0284c7";
        button.style.background = "linear-gradient(180deg, #38bdf8, #0284c7)";
        button.style.color = "#ffffff";
        button.style.fontFamily = "Segoe UI, Tahoma, sans-serif";
        button.style.fontSize = "16px";
        button.style.fontWeight = "700";
        button.style.letterSpacing = "0.2px";
        button.style.cursor = "pointer";
        button.style.boxShadow = "0 10px 22px rgba(2, 132, 199, 0.35)";
        button.style.display = "none";

        button.addEventListener("click", () => {
            if (workflowInProgress) {
                return;
            }
            runDownloadWorkflow();
        });

        document.body.appendChild(button);
        placeDownloadButtonNearCourseContent(button);
        downloadAllButton = button;
        return button;
    }

    function refreshDownloadAllButtonVisibility() {
        const currentCourseUrl = window.location.href.split("#")[0];
        if (currentCourseUrl !== lastCourseScreenUrl) {
            lastCourseScreenUrl = currentCourseUrl;
            courseContentHeadingAnchor = null;
        }

        const button = ensureDownloadAllButton();
        const ready = isCourseScreenReady();
        if (ready) {
            const placed = placeDownloadButtonNearCourseContent(button);
            button.style.display = placed ? "inline-flex" : "none";
            return;
        }

        button.style.display = "none";
    }

    function setDownloadButtonBusyState(isBusy) {
        const button = ensureDownloadAllButton();
        if (isBusy) {
            button.textContent = "Downloading...";
            button.disabled = true;
            button.style.opacity = "0.75";
            button.style.cursor = "wait";
            return;
        }
        button.textContent = "Download all";
        button.disabled = false;
        button.style.opacity = "1";
        button.style.cursor = "pointer";
    }

    async function runDownloadWorkflow() {
        if (workflowInProgress) {
            return;
        }
        workflowInProgress = true;
        activeCourseLabel = "";
        setDownloadButtonBusyState(true);

        try {
            ensureProgressWidget();
            setProgressCloseButtonVisible(false);
            startProgressElapsedTimer();
            updateProgressWidget("Starting...", 0, "Loading...", { allowDecrease: true });

            logStep("Workflow", "Run started");
            setLoadingStatus("Authenticating subscription");
            await ensureProfileWhitelisted();

            setLoadingStatus("Discovering course structure");
            runRootFolder = await buildCourseRootFolder(window.location.href);
            activeCourseLabel = String(runRootFolder || "").trim();
            updateProgressWidget("Discovering course structure", 0, "Loading...", { allowDecrease: true });
            logStep("2/4 Structure", "Using archive name", { archiveName: runRootFolder });
            const children = await extractLinks(document, "");
            const uniqueChildren = removeDuplicateFilenames(children);
            const duplicateCount = Math.max(0, children.length - uniqueChildren.length);
            if (duplicateCount > 0) {
                logStep("2/4 Structure", "Removed duplicate file names", { duplicateCount });
            }
            logStep("2/4 Structure", "File list ready", { count: uniqueChildren.length });

            const downloadTasks = [];
            setLoadingStatus("Resolving download URLs");
            logStep("3/4 Zip", "Resolving file download URLs");
            const resolvedPayload = await resolveDownloadTasks(uniqueChildren, (resolvedCount, totalToResolve, name) => {
                const latest = compactProgressName(name);
                const detail = latest
                    ? `${resolvedCount}/${totalToResolve} files | done: ${latest}`
                    : `${resolvedCount}/${totalToResolve} files`;
                const resolvePct = totalToResolve > 0
                    ? Math.min(50, Math.floor((resolvedCount / totalToResolve) * 50))
                    : 50;
                updateProgressWidget("Resolving download URLs", resolvePct, detail, { allowDecrease: true });
            }, 10);
            downloadTasks.push(...resolvedPayload.tasks);

            logStep("3/4 Zip", "URL resolution mode", {
                parallelResolved: resolvedPayload.parallelCount,
                outlineResolvedSequentially: resolvedPayload.outlineCount,
                totalResolved: resolvedPayload.total
            });

            logStep("3/4 Zip", "Starting parallel blob download stage", {
                taskCount: downloadTasks.length,
                concurrency: 4
            });

            console.log("[BB Downloader][3/4 Zip] Resolved download URLs", downloadTasks.map((task) => ({
                filename: task.filename,
                url: task.downloadUrl
            })));
            for (const task of downloadTasks) {
                console.log(`[BB Downloader][3/4 Zip] About to download: ${task.downloadUrl}`);
            }

            if (downloadTasks.length === 0) {
                updateProgressWidget("No files to download", 100, "0/0 files");
                throw new Error("No downloadable URLs resolved");
            }

            updateProgressWidget("Downloading file data", 50, `${downloadTasks.length} files`);
            const blobs = await downloadBlobsInParallel(downloadTasks, 4, (completed, total, name) => {
                const latest = compactProgressName(name);
                const detail = latest
                    ? `${completed}/${total} files | done: ${latest}`
                    : `${completed}/${total} files`;
                const blobPct = total > 0 ? Math.min(40, Math.floor((completed / total) * 40)) : 40;
                updateProgressWidget("Downloading file data", 50 + blobPct, detail, { allowDecrease: true });
            });

            updateProgressWidget("Creating ZIP", 92, `${blobs.length} files`);
            await addFolders(Array.from(zipFolders));
            await addFiles(blobs);
            await downloadZip(`${runRootFolder || "blackboard_download"}.zip`);
            stopProgressElapsedTimer();
            updateElapsedLabel();
            updateProgressWidget("Download complete", 100, "Done");
            setProgressCloseButtonVisible(true);
            logStep("4/4 Download", "ZIP download triggered");
        } catch (error) {
            console.log("Workflow failed", error);
            stopProgressElapsedTimer();
            updateElapsedLabel();
            updateProgressWidget("Failed", 100, String(error && error.message ? error.message : "Unknown error"));
            setProgressCloseButtonVisible(true);
        } finally {
            workflowInProgress = false;
            activeCourseLabel = "";
            setDownloadButtonBusyState(false);
        }
    }

    window.addEventListener("popstate", refreshDownloadAllButtonVisibility);
    window.addEventListener("hashchange", refreshDownloadAllButtonVisibility);
    window.addEventListener("resize", refreshDownloadAllButtonVisibility);
    setInterval(refreshDownloadAllButtonVisibility, 1000);
    refreshDownloadAllButtonVisibility();
})()
