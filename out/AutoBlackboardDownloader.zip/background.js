const latestPdfUrlByTab = new Map();
const signedPdfBySourceKeyAndTab = new Map();

function getTabMap(tabId) {
  if (!signedPdfBySourceKeyAndTab.has(tabId)) {
    signedPdfBySourceKeyAndTab.set(tabId, new Map());
  }
  return signedPdfBySourceKeyAndTab.get(tabId);
}

function toSourceKey(url) {
  try {
    const parsed = new URL(url);
    const full = `${parsed.origin}${parsed.pathname}`;
    const keyMatch = full.match(/pid-\d+-dt-content-rid-[^/]+\/xid-[^/?#]+/i);
    if (keyMatch) {
      return keyMatch[0].toLowerCase();
    }
    return full.toLowerCase();
  } catch {
    return String(url || "").split("#")[0].toLowerCase();
  }
}

function looksLikeSignedPdfUrl(url) {
  const lowerUrl = String(url || "").toLowerCase();
  return (
    lowerUrl.includes("blackboardcdn.com") &&
    (lowerUrl.includes("response-content-disposition=") || lowerUrl.includes("response-content-type=application%2fpdf"))
  );
}

chrome.webRequest.onCompleted.addListener(
  (details) => {
    if (details.tabId < 0 || !details.url) {
      return;
    }

    if (!looksLikeSignedPdfUrl(details.url)) {
      return;
    }

    latestPdfUrlByTab.set(details.tabId, details.url);
  },
  { urls: ["https://*.blackboardcdn.com/*"] }
);

chrome.webRequest.onBeforeRedirect.addListener(
  (details) => {
    if (details.tabId < 0 || !details.url || !details.redirectUrl) {
      return;
    }

    const sourceLower = details.url.toLowerCase();
    if (!sourceLower.includes("/bbcswebdav/")) {
      return;
    }

    if (!looksLikeSignedPdfUrl(details.redirectUrl)) {
      return;
    }

    const key = toSourceKey(details.url);
    const tabMap = getTabMap(details.tabId);
    tabMap.set(key, details.redirectUrl);
    latestPdfUrlByTab.set(details.tabId, details.redirectUrl);
  },
  { urls: ["https://blackboard.cuhk.edu.hk/*", "https://*.blackboardcdn.com/*"] }
);

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const senderTabId = sender && sender.tab ? sender.tab.id : undefined;
  const tabId = typeof message?.tabId === "number" ? message.tabId : senderTabId;

  if (message?.type === "resetPdfCapture") {
    if (typeof tabId === "number") {
      latestPdfUrlByTab.delete(tabId);
      signedPdfBySourceKeyAndTab.delete(tabId);
    }
    sendResponse({ ok: true });
    return;
  }

  if (message?.type === "getCapturedPdfUrlForSource") {
    const sourceUrl = String(message?.sourceUrl || "");
    const sourceKey = toSourceKey(sourceUrl);
    const tabMap = typeof tabId === "number" ? getTabMap(tabId) : new Map();
    const url = tabMap.get(sourceKey) || "";
    sendResponse({ url });
    return;
  }

  if (message?.type === "resetPdfCaptureForSource") {
    if (typeof tabId === "number") {
      const sourceUrl = String(message?.sourceUrl || "");
      const sourceKey = toSourceKey(sourceUrl);
      const tabMap = getTabMap(tabId);
      tabMap.delete(sourceKey);
    }
    sendResponse({ ok: true });
    return;
  }

  if (message?.type === "getCapturedPdfUrl") {
    const url = typeof tabId === "number" ? (latestPdfUrlByTab.get(tabId) || "") : "";
    sendResponse({ url });
    return;
  }

  if (message?.type === "resolveUrlForBackend") {
    const sourceUrl = String(message?.sourceUrl || "").trim();
    if (!sourceUrl) {
      sendResponse({ url: "", error: "Missing sourceUrl" });
      return;
    }

    (async () => {
      try {
        const response = await fetch(sourceUrl, {
          method: "GET",
          credentials: "include",
          redirect: "follow"
        });

        const finalUrl = String(response?.url || sourceUrl);
        sendResponse({
          url: finalUrl,
          status: response?.status || 0,
          ok: Boolean(response?.ok)
        });
      } catch (error) {
        sendResponse({
          url: sourceUrl,
          error: String(error && error.message ? error.message : error)
        });
      }
    })();

    return true;
  }
});